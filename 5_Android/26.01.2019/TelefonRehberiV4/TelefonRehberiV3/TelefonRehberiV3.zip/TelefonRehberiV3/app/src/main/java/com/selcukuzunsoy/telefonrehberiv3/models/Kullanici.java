package com.selcukuzunsoy.telefonrehberiv3.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Kullanici {

    private String kadi;
    private String sifre;

}
